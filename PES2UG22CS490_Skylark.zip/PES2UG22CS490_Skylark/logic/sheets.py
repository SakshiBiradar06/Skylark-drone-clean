import gspread
from google.oauth2.service_account import Credentials

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive"
]

creds = Credentials.from_service_account_file(
    "service_account.json",
    scopes=SCOPES
)

client = gspread.authorize(creds)



def update_pilot_status(pilot_id, new_status):
   
    try:
        print(f"[DEBUG] Updating pilot {pilot_id} to {new_status} (simulated)")
        return True  
    except Exception as e:
        return False


