# # import pandas as pd

# # def load_pilots():
# #     return pd.read_csv("data/pilot_roster.csv")

# # def get_available_pilots(skill=None, location=None):
# #     df = load_pilots()
# #     df = df[df["status"] == "Available"]

# #     if skill:
# #         df = df[df["skills"].str.contains(skill, case=False, na=False)]
# #     if location:
# #         df = df[df["current location"].str.contains(location, case=False, na=False)]

# #     return df


# import pandas as pd

# # ---------- CSV BASED READ (USED FOR LOCAL LOGIC & UI) ----------

# def load_pilots():
#     return pd.read_csv("data/pilot_roster.csv")

# def get_available_pilots(skill=None, location=None):
#     df = load_pilots()

#     # Only available pilots
#     df = df[df["status"].str.lower() == "available"]

#     if skill:
#         df = df[df["skills"].str.contains(skill, case=False, na=False)]

#     if location:
#         df = df[df["location"].str.contains(location, case=False, na=False)]

#     return df


# # ---------- GOOGLE SHEETS WRITE-BACK (REQUIRED FOR ASSIGNMENT) ----------

# from logic.sheets import open_sheet

# def update_pilot_status(pilot_id, new_status):
#     """
#     Updates pilot status in Google Sheet (2-way sync requirement)
#     """
#     try:
#         sheet = open_sheet("Pilot Roster")  # MUST match sheet name exactly
#         records = sheet.get_all_records()

#         for idx, row in enumerate(records, start=2):  # start=2 → skip header
#             if row.get("pilot_id") == pilot_id:
#                 sheet.update_cell(idx, 6, new_status)  # column 6 = status
#                 return f"Pilot {pilot_id} status updated to {new_status}"

#         return "Pilot not found in Google Sheet"

#     except Exception as e:
#         return f"Error updating pilot status: {str(e)}"


import pandas as pd

def load_pilots():
    return pd.read_csv("data/pilot_roster.csv")

def get_available_pilots(skill=None, location=None):
    df = load_pilots()
    df = df[df["status"] == "Available"]

    if skill:
        df = df[df["skills"].str.contains(skill, case=False, na=False)]
    if location:
        df = df[df["current location"].str.contains(location, case=False, na=False)]

    return df
