import pandas as pd

def load_missions():
    return pd.read_csv("data/missions.csv")
