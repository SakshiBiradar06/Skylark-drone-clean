from logic.roster import load_pilots
from logic.drone_inventory import load_drones

def urgent_reassign(skill, location):
    pilots = load_pilots()
    drones = load_drones()

    backup_pilots = pilots[
        (pilots["status"] == "Available") &
        (pilots["skills"].str.contains(skill, case=False)) &
        (pilots["location"] == location)
    ]

    backup_drones = drones[
        (drones["status"] == "Available") &
        (drones["capabilities"].str.contains(skill, case=False)) &
        (drones["location"] == location)
    ]

    if backup_pilots.empty and backup_drones.empty:
        return ["❌ No backup pilot or drone available"]

    results = []

    if not backup_pilots.empty:
        p = backup_pilots.iloc[0]
        results.append(f"🚨 Backup Pilot: {p['name']} ({p['pilot_id']})")

    if not backup_drones.empty:
        d = backup_drones.iloc[0]
        results.append(f"🚁 Backup Drone: {d['drone_id']} ({d['model']})")

    return results
