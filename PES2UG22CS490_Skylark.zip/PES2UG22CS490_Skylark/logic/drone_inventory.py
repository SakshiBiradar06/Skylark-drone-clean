import pandas as pd

def load_drones():
    return pd.read_csv("data/drone_fleet.csv")

def get_available_drones():
    df = load_drones()
    return df[df["status"] == "Available"]

def get_maintenance_issues():
    df = load_drones()
    return df[df["status"] == "In Maintenance"]
