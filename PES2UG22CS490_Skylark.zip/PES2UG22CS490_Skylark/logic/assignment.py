import pandas as pd
from logic.roster import load_pilots
from logic.missions import load_missions

def match_pilots_to_missions():
    pilots = load_pilots()
    missions = load_missions()

    matches = []

    for _, m in missions.iterrows():
        eligible = pilots[
            (pilots["skills"] == m["required_skill"]) &
            (pilots["location"] == m["location"]) &
            (pilots["status"] == "Available")
        ]

        for _, p in eligible.iterrows():
            matches.append({
                "pilot": p["name"],
                "project": m["project_id"]
            })

    return pd.DataFrame(matches)
