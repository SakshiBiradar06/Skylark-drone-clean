

from logic.roster import load_pilots
from logic.drone_inventory import load_drones
import pandas as pd


def detect_conflicts():
    conflicts = []

    pilots = load_pilots()
    drones = load_drones()

    # ---- DRONE CONFLICTS ----
    for _, d in drones.iterrows():
        if (
            d["status"] == "In Maintenance"
            and pd.notna(d["assigned_project"])
            and str(d["assigned_project"]).strip() != ""
        ):
            conflicts.append(
                f"Drone {d['drone_id']} assigned to {d['assigned_project']} but under maintenance"
            )

    if not conflicts:
        conflicts.append("✅ No conflicts detected.")

    return conflicts
