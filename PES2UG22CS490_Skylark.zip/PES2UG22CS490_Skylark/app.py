

import streamlit as st

from logic.roster import get_available_pilots
from logic.drone_inventory import get_available_drones, get_maintenance_issues
from logic.assignment import match_pilots_to_missions
from logic.conflicts import detect_conflicts
from logic.urgent import urgent_reassign
from logic.sheets import update_pilot_status


st.set_page_config(
    page_title="Skylark Drone Ops Agent",
    layout="wide"
)

st.title("🚁 Skylark Drones – Operations Coordinator AI Agent")

st.markdown("""
**Try commands like:**
- `show available pilots`
- `show available drones`
- `show maintenance issues`
- `match pilots to missions`
- `show conflicts`
- `mark pilot P001 as on leave`
- `urgent reassignment mapping bangalore`
""")

command = st.text_input("Enter a command:")

if command:
    cmd = command.lower().strip()
    st.info(f"Received command: {command}")

    # ---------------- ROSTER ----------------
    if "available" in cmd and "pilot" in cmd:
        pilots = get_available_pilots()
        st.dataframe(pilots)

    # ---------------- DRONES ----------------
    elif "available" in cmd and "drone" in cmd:
        drones = get_available_drones()
        st.dataframe(drones)

    elif "maintenance" in cmd:
        issues = get_maintenance_issues()
        if issues.empty:
            st.success("✅ No drones currently under maintenance issues.")
        else:
            st.dataframe(issues)

    # ---------------- ASSIGNMENTS ----------------
    elif "match" in cmd:
        matches = match_pilots_to_missions()
        if matches.empty:
            st.warning("⚠️ No valid pilot–mission matches found.")
        else:
            st.dataframe(matches)

    # ---------------- CONFLICTS ----------------
    elif "conflict" in cmd:
        conflicts = detect_conflicts()
        if not conflicts:
            st.success("✅ No conflicts detected.")
        else:
            for c in conflicts:
                st.error(c)

    # ---------------- MARK PILOT ON LEAVE ----------------
    elif "mark pilot" in cmd and "on leave" in cmd:
        try:
            pilot_id = cmd.split()[2].upper()
            success = update_pilot_status(pilot_id, "On Leave")

            if success:
                st.success(f"✅ Pilot {pilot_id} marked as On Leave")
            else:
                st.error(f"❌ Pilot {pilot_id} not found")

        except Exception as e:
            st.error(str(e))

    # ---------------- URGENT ----------------
    elif "urgent" in cmd:
        parts = cmd.split()
        skill = parts[-2].capitalize()
        location = parts[-1].capitalize()

        result = urgent_reassign(skill, location)

        if not result:
            st.warning("⚠️ No urgent reassignment possible.")
        else:
            for r in result:
                st.warning(r)

    else:
        st.warning(
            "Command not recognized. "
            "Try: show available pilots / drones / maintenance / conflicts"
        )
