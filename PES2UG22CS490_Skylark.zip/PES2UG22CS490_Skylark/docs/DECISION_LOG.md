# Skylark Drones – Drone Operations Coordinator AI Agent
## Decision Log

---

## 1. Key Assumptions

- CSV files represent the operational database for pilots, drones, and missions.
- Pilot availability is determined using `status`, `current_assignment`, and date ranges.
- Drone availability depends on operational status and maintenance state.
- Skill matching is based on string matching between pilot skills, drone capabilities, and mission requirements.
- Location must match between pilot, drone, and mission for assignment.
- The system is operated by a single coordinator via a conversational interface.

---

## 2. Trade-offs and Design Decisions

### Rule-based Logic vs Machine Learning
A rule-based approach was chosen over machine learning because:
- Operational decisions must be explainable.
- Data volume is small and structured.
- Deterministic behavior is preferred in safety-critical drone operations.

### Streamlit for UI
Streamlit was selected because:
- It enables rapid prototyping within the 6-hour time constraint.
- It provides a simple conversational-style interface.
- It is easy to host and test without local setup.

### CSV + Pandas Architecture
- Pandas enables fast filtering, validation, and conflict detection.
- CSV files simulate real backend systems like Google Sheets or databases.
- This design allows easy extension to 2-way Google Sheets sync.

---

## 3. Urgent Reassignments (Bonus Requirement)

Urgent reassignment was interpreted as the system’s ability to immediately
recommend backup pilots and drones when conflicts, maintenance issues,
or high-priority missions arise.

The agent dynamically identifies the next-best available pilot and drone
based on:
- Required skill
- Location
- Current availability

This allows operations to continue without manual coordination and mirrors
real-world drone fleet management scenarios where rapid response is critical.

---

## 4. Conflict Detection and Error Handling

The agent automatically detects and reports:
- Pilot double-booking across overlapping project timelines.
- Pilots assigned to missions without the required skills.
- Drones assigned while under maintenance.
- Pilot and drone location mismatches.

Conflicts are clearly surfaced to the user instead of failing silently,
allowing the coordinator to make informed decisions.

---

## 5. Google Sheets Integration Approach

- Google Sheets acts as the external system of record.
- The agent reads pilot and drone data from Sheets.
- Pilot status updates are written back to the Pilot Roster sheet.
- This ensures 2-way synchronization between the AI agent and operational data.

---

## 6. What I Would Improve With More Time

- Add automatic write-back for mission assignments.
- Introduce priority-based reassignment logic.
- Add authentication and role-based access.
- Implement timeline-based visual scheduling.
- Extend the agent to support multi-day mission planning.

---

## 7. Summary

This AI agent reduces coordination overhead by automating pilot assignment,
drone availability tracking, conflict detection, and urgent reassignments.
The system is explainable, deterministic, and aligned with real-world
drone operations workflows.
